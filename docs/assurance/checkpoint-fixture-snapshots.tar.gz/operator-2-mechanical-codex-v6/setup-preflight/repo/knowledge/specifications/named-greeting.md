---
type: Specification
title: Named greeting
status: draft
target: /capabilities/greeting.md
---
# Named greeting

## Target baseline

Target: /capabilities/greeting.md
- GREET-R1: sha256:6629bc812006ffa620474a492a76177378047922bf522672da89b6555e41cadc
- GREET-R2: absent

## Modified requirements

- GREET-R1: The greeting MUST start with Hello.

## Added requirements

- GREET-R2: The greeting MUST include the supplied name after a comma and space.

## Removed requirements

None.

## Acceptance

- GREET-R1: `python3 -m unittest test_greeting` passes.
- GREET-R2: `python3 -m unittest test_greeting` passes.

## Constraints

Change util.py only among application files.

## Non-goals

Other utilities.

## Assumptions

The task input grants approval for this delta and its implementation plan.

## Open questions

None.
