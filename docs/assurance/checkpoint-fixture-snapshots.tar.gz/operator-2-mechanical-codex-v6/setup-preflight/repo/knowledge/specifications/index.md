# Specifications

<!-- okf:index:begin -->
- [Named greeting](named-greeting.md)
<!-- okf:index:end -->
