---
type: Capability
title: Greeting
namespace: GREET
status: stable
---
# Greeting

## Requirements

- GREET-R1: The greeting MUST return hello.

## Notes

Preserve unrelated documentation.
