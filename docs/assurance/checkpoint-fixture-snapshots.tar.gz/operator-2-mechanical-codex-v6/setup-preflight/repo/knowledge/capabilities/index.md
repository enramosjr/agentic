# Capabilities

<!-- okf:index:begin -->
- [Greeting](greeting.md)
<!-- okf:index:end -->
