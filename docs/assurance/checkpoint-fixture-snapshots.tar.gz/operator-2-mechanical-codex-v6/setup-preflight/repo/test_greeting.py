import unittest
from util import greet

class Greeting(unittest.TestCase):
    def test_name(self):
        self.assertEqual(greet('Ada'), 'Hello, Ada')
        self.assertEqual(greet('Bo'), 'Hello, Bo')

if __name__ == '__main__':
    unittest.main()
